# 1.1.0

* Make some members internal
* Add a bunch of missing members. Probably should have not uploaded this yet. Oops.

# 1.0.0

* Initial release of the mod.